// ============================================================
//  AccesoPRO — Backend API (Node.js + Express + Supabase)
//  server.js
// ============================================================
require('dotenv').config();
const express    = require('express');
const cors       = require('cors');
const bcrypt     = require('bcryptjs');
const jwt        = require('jsonwebtoken');
const rateLimit  = require('express-rate-limit');
const { createClient } = require('@supabase/supabase-js');

// ─── Supabase client ────────────────────────────────────────
const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY,
  { auth: { persistSession: false } }
);

// ─── Express setup ──────────────────────────────────────────
const app  = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(cors({
  origin: process.env.FRONTEND_URL ? process.env.FRONTEND_URL : true,
  methods: ['GET','POST','PUT','DELETE'],
  allowedHeaders: ['Content-Type','Authorization']
}));

// ─── Rate limiting ──────────────────────────────────────────
const generalLimit = rateLimit({ windowMs: 15*60*1000, max: 200 });
const pinLimit     = rateLimit({ windowMs: 1*60*1000,  max: 20,
  message: { error: 'Demasiados intentos. Espera 1 minuto.' }
});
const loginLimit   = rateLimit({ windowMs: 15*60*1000, max: 10,
  message: { error: 'Demasiados intentos de login.' }
});

app.use(generalLimit);

// ─── Helpers ────────────────────────────────────────────────
const ok  = (res, data, status=200) => res.status(status).json({ ok:true,  ...data });
const err = (res, msg,  status=400) => res.status(status).json({ ok:false, error:msg });

// Envuelve cualquier ruta async: si algo lanza una excepción (timeout de red,
// Supabase caído, etc.) responde con 500 en vez de dejar la petición colgada.
const safe = (fn) => async (req, res) => {
  try {
    await fn(req, res);
  } catch (e) {
    console.error(`Error en ${req.method} ${req.path}:`, e.message);
    if (!res.headersSent) err(res, 'Error interno del servidor', 500);
  }
};

// ─── Auth middleware ─────────────────────────────────────────
function requireAuth(req, res, next) {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer '))
    return err(res, 'Token requerido', 401);
  try {
    req.admin = jwt.verify(header.split(' ')[1], process.env.JWT_SECRET);
    next();
  } catch {
    err(res, 'Token inválido o expirado', 401);
  }
}

// ─── Inicialización: hashear contraseña del admin default ───
async function seedAdminPassword() {
  const hash = await bcrypt.hash('admin123', 10);
  await supabase
    .from('admins')
    .update({ password: hash })
    .eq('username', 'admin')
    .eq('password', '$2b$10$placeholder');
  console.log('✅ Admin password inicializada');
}

// ============================================================
//  RUTAS PÚBLICAS (sin auth)
// ============================================================

// Health check
app.get('/health', (req, res) => ok(res, { status:'running', ts: new Date() }));

// ─── POST /api/auth/login ────────────────────────────────────
app.post('/api/auth/login', loginLimit, async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) return err(res, 'Usuario y contraseña requeridos');

    const { data: admin, error } = await supabase
      .from('admins')
      .select('*')
      .eq('username', username)
      .single();

    if (error || !admin) return err(res, 'Credenciales incorrectas', 401);

    const valid = await bcrypt.compare(password, admin.password);
    if (!valid) return err(res, 'Credenciales incorrectas', 401);

    const token = jwt.sign(
      { id: admin.id, username: admin.username, name: admin.full_name },
      process.env.JWT_SECRET,
      { expiresIn: '8h' }
    );
    ok(res, { token, admin: { id: admin.id, username: admin.username, name: admin.full_name } });
  } catch (e) {
    console.error('Error en /api/auth/login:', e.message);
    err(res, 'Error interno del servidor', 500);
  }
});

// ─── POST /api/punch ─────────────────────────────────────────
// Ruta pública — usada por el kiosko de ponche
app.post('/api/punch', pinLimit, async (req, res) => {
  try {
    const { pin } = req.body;
    if (!pin || !/^\d{4}$/.test(pin)) return err(res, 'PIN inválido');

    // Buscar empleado
    const { data: emp, error: empErr } = await supabase
      .from('employees')
      .select('id, first_name, last_name, status, dept_id, role, departments(name,color)')
      .eq('pin', pin)
      .eq('active', true)
      .single();

    if (empErr || !emp) return err(res, 'PIN no reconocido', 404);

    // Determinar tipo de ponche
    const newStatus = emp.status === 'in' ? 'out' : 'in';
    const punchType = newStatus;

    // Registrar en punch_logs
    const { error: logErr } = await supabase
      .from('punch_logs')
      .insert({
        employee_id: emp.id,
        type: punchType,
        ip_address: req.ip,
        device: req.headers['user-agent']?.slice(0,100) || null
      });

    if (logErr) return err(res, 'Error registrando ponche', 500);

    // Actualizar estado del empleado
    const { error: updateErr } = await supabase
      .from('employees')
      .update({ status: newStatus })
      .eq('id', emp.id);

    if (updateErr) return err(res, 'Ponche registrado, pero no se pudo actualizar el estado', 500);

    ok(res, {
      employee: {
        id:        emp.id,
        name:      `${emp.first_name} ${emp.last_name}`,
        dept:      emp.departments?.name,
        deptColor: emp.departments?.color,
        role:      emp.role,
        newStatus
      },
      punch: { type: punchType, time: new Date().toISOString() }
    });
  } catch (e) {
    console.error('Error en /api/punch:', e.message);
    err(res, 'Error interno del servidor', 500);
  }
});

// ============================================================
//  RUTAS PROTEGIDAS (requieren JWT)
// ============================================================

// ─── GET /api/employees ──────────────────────────────────────
app.get('/api/employees', requireAuth, safe(async (req, res) => {
  const { data, error } = await supabase
    .from('employees')
    .select('*, departments(name,color)')
    .eq('active', true)
    .order('first_name');
  if (error) return err(res, 'Error al obtener empleados', 500);
  ok(res, { employees: data });
}));

// ─── POST /api/employees ─────────────────────────────────────
app.post('/api/employees', requireAuth, safe(async (req, res) => {
  const { first_name, last_name, email, dept_id, role, pin } = req.body;
  if (!first_name || !last_name || !pin)
    return err(res, 'Nombre, apellido y PIN son requeridos');
  if (!/^\d{4}$/.test(pin))
    return err(res, 'El PIN debe ser exactamente 4 dígitos');

  const { data, error } = await supabase
    .from('employees')
    .insert({ first_name, last_name, email, dept_id, role, pin })
    .select('*, departments(name,color)')
    .single();

  if (error) {
    if (error.code === '23505') return err(res, 'PIN o email ya está en uso');
    return err(res, 'Error al crear empleado', 500);
  }
  ok(res, { employee: data }, 201);
}));

// ─── PUT /api/employees/:id ──────────────────────────────────
app.put('/api/employees/:id', requireAuth, safe(async (req, res) => {
  const { id } = req.params;
  const { first_name, last_name, email, dept_id, role, pin } = req.body;
  if (pin && !/^\d{4}$/.test(pin))
    return err(res, 'El PIN debe ser exactamente 4 dígitos');

  const updates = {};
  if (first_name) updates.first_name = first_name;
  if (last_name)  updates.last_name  = last_name;
  if (email)      updates.email      = email;
  if (dept_id)    updates.dept_id    = dept_id;
  if (role)       updates.role       = role;
  if (pin)        updates.pin        = pin;

  const { data, error } = await supabase
    .from('employees')
    .update(updates)
    .eq('id', id)
    .select('*, departments(name,color)')
    .single();

  if (error) {
    if (error.code === '23505') return err(res, 'PIN o email ya está en uso');
    return err(res, 'Error al actualizar empleado', 500);
  }
  ok(res, { employee: data });
}));

// ─── DELETE /api/employees/:id ───────────────────────────────
app.delete('/api/employees/:id', requireAuth, safe(async (req, res) => {
  const { id } = req.params;
  // Soft delete — preserva historial
  const { error } = await supabase
    .from('employees')
    .update({ active: false })
    .eq('id', id);
  if (error) return err(res, 'Error al eliminar empleado', 500);
  ok(res, { message: 'Empleado desactivado' });
}));

// ─── GET /api/logs ───────────────────────────────────────────
app.get('/api/logs', requireAuth, safe(async (req, res) => {
  const { from, to, employee_id, limit = 100 } = req.query;
  let query = supabase
    .from('punch_logs')
    .select('*, employees(first_name, last_name, role, departments(name))')
    .order('punched_at', { ascending: false })
    .limit(parseInt(limit));

  if (from)        query = query.gte('punched_at', from);
  if (to)          query = query.lte('punched_at', to);
  if (employee_id) query = query.eq('employee_id', employee_id);

  const { data, error } = await query;
  if (error) return err(res, 'Error al obtener logs', 500);
  ok(res, { logs: data });
}));

// ─── DELETE /api/logs ────────────────────────────────────────
app.delete('/api/logs', requireAuth, safe(async (req, res) => {
  const { error } = await supabase.from('punch_logs').delete().neq('id', '00000000-0000-0000-0000-000000000000');
  if (error) return err(res, 'Error al limpiar logs', 500);
  // Reset estados
  await supabase.from('employees').update({ status:'out' }).eq('active', true);
  ok(res, { message: 'Logs eliminados y estados reiniciados' });
}));

// ─── GET /api/departments ────────────────────────────────────
app.get('/api/departments', requireAuth, safe(async (req, res) => {
  const { data, error } = await supabase.from('departments').select('*').order('name');
  if (error) return err(res, 'Error al obtener departamentos', 500);
  ok(res, { departments: data });
}));

// ─── GET /api/stats ──────────────────────────────────────────
app.get('/api/stats', requireAuth, safe(async (req, res) => {
  const today = new Date();
  today.setHours(0,0,0,0);

  const [empRes, presentRes, punchesRes] = await Promise.all([
    supabase.from('employees').select('id', { count:'exact' }).eq('active', true),
    supabase.from('employees').select('id', { count:'exact' }).eq('status','in').eq('active', true),
    supabase.from('punch_logs').select('id', { count:'exact' }).gte('punched_at', today.toISOString())
  ]);

  ok(res, {
    total:    empRes.count     || 0,
    present:  presentRes.count || 0,
    absent:   (empRes.count    || 0) - (presentRes.count || 0),
    punches:  punchesRes.count || 0
  });
}));

// ─── PUT /api/auth/password ──────────────────────────────────
app.put('/api/auth/password', requireAuth, safe(async (req, res) => {
  const { currentPassword, newPassword } = req.body;
  if (!currentPassword || !newPassword) return err(res, 'Contraseñas requeridas');
  if (newPassword.length < 6) return err(res, 'Mínimo 6 caracteres');

  const { data: admin } = await supabase
    .from('admins').select('password').eq('id', req.admin.id).single();

  const valid = await bcrypt.compare(currentPassword, admin.password);
  if (!valid) return err(res, 'Contraseña actual incorrecta', 401);

  const hash = await bcrypt.hash(newPassword, 10);
  await supabase.from('admins').update({ password: hash }).eq('id', req.admin.id);
  ok(res, { message: 'Contraseña actualizada' });
}));

// ─── 404 handler ─────────────────────────────────────────────
app.use((req, res) => err(res, `Ruta ${req.path} no encontrada`, 404));

// ─── Start ───────────────────────────────────────────────────
app.listen(PORT, async () => {
  console.log(`\n🚀 AccesoPRO API corriendo en puerto ${PORT}`);
  console.log(`   Entorno: ${process.env.NODE_ENV || 'development'}`);
  console.log(`   Supabase: ${process.env.SUPABASE_URL ? '✅ conectado' : '❌ falta SUPABASE_URL'}`);
  await seedAdminPassword().catch(e => console.log('Admin ya configurado'));
});
