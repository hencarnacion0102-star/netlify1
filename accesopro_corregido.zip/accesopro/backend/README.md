# AccesoPRO — Backend API

API REST para el sistema de control de acceso de empleados.

## Stack
- Node.js + Express
- Supabase (PostgreSQL)
- JWT para autenticación
- bcryptjs para contraseñas

## Setup local

```bash
npm install
cp .env.example .env
# Edita .env con tus credenciales de Supabase
npm run dev
```

## Variables de entorno requeridas

```
SUPABASE_URL=https://TU_PROYECTO.supabase.co
SUPABASE_SERVICE_KEY=eyJhbGci...
JWT_SECRET=string_secreto_largo
PORT=3000
NODE_ENV=production
FRONTEND_URL=https://tu-frontend.vercel.app
```

## Endpoints

| Método | Ruta | Auth | Descripción |
|--------|------|------|-------------|
| GET | /health | No | Estado del servidor |
| POST | /api/auth/login | No | Login admin |
| PUT | /api/auth/password | Sí | Cambiar contraseña |
| POST | /api/punch | No | Registrar ponche por PIN |
| GET | /api/employees | Sí | Listar empleados |
| POST | /api/employees | Sí | Crear empleado |
| PUT | /api/employees/:id | Sí | Actualizar empleado |
| DELETE | /api/employees/:id | Sí | Eliminar empleado |
| GET | /api/logs | Sí | Historial de ponches |
| DELETE | /api/logs | Sí | Limpiar logs |
| GET | /api/departments | Sí | Listar departamentos |
| GET | /api/stats | Sí | Estadísticas del día |

## Deploy en Railway

1. Sube este repositorio a GitHub
2. Conecta Railway con el repo
3. Agrega las variables de entorno en Railway → Variables
4. Railway detecta Node.js automáticamente y hace el deploy

## Credenciales por defecto
- Usuario: `admin`
- Contraseña: `admin123`
