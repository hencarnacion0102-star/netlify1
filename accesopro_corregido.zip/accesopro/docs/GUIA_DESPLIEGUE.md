# AccesoPRO — Guía de Despliegue
## Supabase + Railway + Vercel (100% Gratis)

---

## PASO 1 — Supabase (Base de datos)

1. Ve a https://supabase.com → "Start your project"
2. Crea una cuenta gratuita
3. Click en **"New project"** → ponle nombre: `accesopro`
4. Elige una contraseña segura para la DB → **guárdala**
5. Selecciona región: **us-east-1** (más cercano a RD)
6. Espera ~2 minutos que se cree el proyecto

### Ejecutar el Schema:
1. En el sidebar izquierdo → **SQL Editor**
2. Click en **"New query"**
3. Copia y pega todo el contenido de `supabase_schema.sql`
4. Click **"Run"** → Deberías ver "Success"

### Obtener tus credenciales:
1. Ve a **Project Settings** (ícono engranaje) → **API**
2. Copia:
   - `Project URL` → es tu `SUPABASE_URL`
   - `service_role` key → es tu `SUPABASE_SERVICE_KEY` (solo para backend)
   - `anon` key → es tu `SUPABASE_KEY` (para el frontend)

---

## PASO 2 — Railway (Backend Node.js)

1. Ve a https://railway.app → "Start a New Project"
2. Conecta tu cuenta de GitHub
3. Sube la carpeta `backend/` a un repo en GitHub
   ```bash
   cd accesopro/backend
   git init
   git add .
   git commit -m "AccesoPRO backend"
   git branch -M main
   git remote add origin https://github.com/TU_USUARIO/accesopro-backend.git
   git push -u origin main
   ```
4. En Railway → **"Deploy from GitHub repo"** → selecciona el repo
5. Railway detecta Node.js automáticamente

### Configurar variables de entorno en Railway:
En tu proyecto Railway → **Variables** → agrega:
```
SUPABASE_URL        = https://TU_PROYECTO.supabase.co
SUPABASE_SERVICE_KEY= eyJhbGci... (service_role key)
JWT_SECRET          = un_string_largo_y_aleatorio_aqui_2024_seguro
NODE_ENV            = production
FRONTEND_URL        = https://tu-app.vercel.app
```

6. Railway te da una URL como: `https://accesopro-backend.up.railway.app`
   → Esta es tu `API_URL` para el frontend

---

## PASO 3 — Vercel (Frontend)

1. Ve a https://vercel.com → conecta GitHub
2. Sube la carpeta `frontend/` a otro repo:
   ```bash
   cd accesopro/frontend
   git init && git add . && git commit -m "AccesoPRO frontend"
   git remote add origin https://github.com/TU_USUARIO/accesopro-frontend.git
   git push -u origin main
   ```
3. En Vercel → "New Project" → importa el repo del frontend
4. Framework Preset: **Other** (es HTML puro)
5. Deploy

### Editar el frontend con tus URLs:
Antes de hacer push, abre `index.html` y cambia estas 3 líneas:
```javascript
const API_URL      = 'https://accesopro-backend.up.railway.app'; // ← URL de Railway
const SUPABASE_URL = 'https://TU_PROYECTO.supabase.co';          // ← URL de Supabase
const SUPABASE_KEY = 'eyJhbGci...anon_key';                      // ← anon key de Supabase
```

---

## PASO 4 — Habilitar Realtime en Supabase

1. En Supabase → **Database** → **Replication**
2. En la sección "Tables" activa:
   - `employees` ✓
   - `punch_logs` ✓
3. Guarda los cambios

---

## Estructura final del proyecto

```
accesopro/
├── backend/
│   ├── server.js          ← API Express completa
│   ├── package.json
│   └── .env.example       ← Copia a .env para desarrollo local
│
├── frontend/
│   └── index.html         ← App completa en un solo archivo
│
└── docs/
    └── supabase_schema.sql ← Schema completo de la BD
```

---

## Desarrollo local

```bash
# 1. Instalar dependencias del backend
cd accesopro/backend
npm install

# 2. Crear archivo .env
cp .env.example .env
# Edita .env con tus credenciales de Supabase

# 3. Iniciar backend
npm run dev
# → Corre en http://localhost:3000

# 4. Abrir frontend
# Abre accesopro/frontend/index.html en el navegador
# (o usa Live Server en VS Code)
```

---

## Endpoints de la API

| Método | Ruta                   | Auth | Descripción                        |
|--------|------------------------|------|------------------------------------|
| GET    | /health                | No   | Verificar estado del servidor      |
| POST   | /api/auth/login        | No   | Login administrador → JWT          |
| PUT    | /api/auth/password     | Sí   | Cambiar contraseña admin           |
| POST   | /api/punch             | No   | Registrar ponche por PIN           |
| GET    | /api/employees         | Sí   | Listar todos los empleados         |
| POST   | /api/employees         | Sí   | Crear empleado                     |
| PUT    | /api/employees/:id     | Sí   | Actualizar empleado                |
| DELETE | /api/employees/:id     | Sí   | Desactivar empleado (soft delete)  |
| GET    | /api/logs              | Sí   | Historial de ponches               |
| DELETE | /api/logs              | Sí   | Limpiar logs                       |
| GET    | /api/departments       | Sí   | Listar departamentos               |
| GET    | /api/stats             | Sí   | Estadísticas del día               |

---

## Credenciales por defecto

- **Usuario admin:** `admin`
- **Contraseña:** `admin123`

⚠️ Cambia la contraseña desde el panel tan pronto despliegues en producción.

---

## Costos estimados (plan gratuito)

| Servicio   | Límite gratuito              | Costo si superas |
|------------|------------------------------|-----------------|
| Supabase   | 500MB DB, 2GB storage        | $25/mes         |
| Railway    | $5 crédito/mes incluido      | ~$5/mes         |
| Vercel     | 100GB bandwidth, ilimitado   | $20/mes         |

Para una empresa pequeña/mediana, el plan gratuito es más que suficiente.
