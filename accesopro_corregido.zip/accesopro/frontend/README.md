# AccesoPRO — Frontend

Aplicación de control de acceso de empleados. Un solo archivo HTML.

## Configuración

Edita las primeras 3 líneas del `<script>` en `index.html`:

```javascript
const API_URL      = 'https://tu-backend.up.railway.app';
const SUPABASE_URL = 'https://TU_PROYECTO.supabase.co';
const SUPABASE_KEY = 'eyJhbGci...anon_key';
```

## Deploy en Vercel

1. Sube este repositorio a GitHub
2. Importa en vercel.com → New Project
3. Framework Preset: **Other**
4. Deploy

## Acceso
- **Kiosko de ponche**: visible sin login — para los empleados
- **Portal Admin**: usuario `admin` / contraseña `admin123`

## Funcionalidades
- Ponche de entrada/salida por PIN de 4 dígitos
- Dashboard con métricas en tiempo real
- CRUD de empleados
- Historial de registros con filtros
- Exportar reportes en PDF y CSV
- Cambio de contraseña del administrador
- Modo Demo (sin backend) para pruebas
